#include"ai.h"

int map[MAX][MAX];
int end_game;
IMAGE img[100];
bool exit_chess = false;


point score_judge(int x, int y, int inverse, int g) {
    point temp = { x,y,0ll };
    if (g >= 2) {
        return temp;
    }
    if (x <= 0 || y <= 0 || x > MAX - 2 || y > MAX - 2) {
        return temp;
    }
    if (map[x][y + 1] == inverse && y + 1 < MAX - 1) {
        if (map[x][y + 2] == inverse && y + 2 < MAX - 1) {
            if (map[x][y + 3] == inverse && y + 3 < MAX - 1) {
                if (map[x][y + 4] == inverse && y + 4 < MAX - 1) {
                    temp.score += MAXA;
                }
                else if (map[x][y - 1] == inverse && y - 1 > 0) {
                    temp.score += MAXA;
                }
                else if (((map[x][y + 4] == inverse * -1 && y + 4 < MAX - 1) || y + 4 >= MAX - 1)
                    && ((map[x][y - 1] == inverse * -1 && y - 1 > 0) || y - 1 <= 0)) {
                    temp.score += MAXD;
                }
                else if (((map[x][y + 4] == inverse * -1 && y + 4 < MAX - 1) || y + 4 >= MAX - 1)
                    || ((map[x][y - 1] == inverse * -1 && y - 1 > 0) || y - 1 <= 0)) {
                    temp.score += MAXC;
                }
                else {
                    temp.score += MAXB;
                }
            }
            else if (map[x][y - 1] == inverse && y - 1 > 0) {
                if (map[x][y - 2] == inverse && y - 2 > 0) {
                    temp.score += MAXA;
                }
                else if (((map[x][y - 2] == inverse * -1 && y - 2 > 0) || y - 2 <= 0)
                    && ((map[x][y + 3] == inverse * -1 && y + 3 < MAX - 1) || y + 3 >= MAX - 1)) {
                    temp.score += MAXD;
                }
                else if (((map[x][y - 2] == inverse * -1 && y - 2 > 0) || y - 2 <= 0)
                    || ((map[x][y + 3] == inverse * -1 && y + 3 < MAX - 1) || y + 3 >= MAX - 1)) {
                    temp.score += MAXC;
                }
                else {
                    temp.score += MAXB;
                }
            }
            else if (((map[x][y - 1] == inverse * -1 && y - 1 > 0) || y - 1 <= 0)
                && ((map[x][y + 3] == inverse * -1 && y + 3 < MAX - 1) || y + 3 >= MAX - 1)) {
                temp.score += MAXE;
            }
            else if (((map[x][y - 1] == inverse * -1 && y - 1 > 0) || y - 1 <= 0)
                || ((map[x][y + 3] == inverse * -1 && y + 3 < MAX - 1) || y + 3 >= MAX - 1)) {
                temp.score += MAXD;
            }
            else {
                temp.score += MAXC;
            }
        }
        else if (map[x][y - 1] == inverse && y - 1 > 0) {
            if (map[x][y - 2] == inverse && y - 2 > 0) {
                if (map[x][y - 3] == inverse && y - 3 > 0) {
                    temp.score += MAXA;
                }
                else if (((map[x][y - 3] == inverse * -1 && y - 3 > 0) || y - 3 <= 0) &&
                    (map[x][y + 2] == inverse * -1 && y + 2 < MAX - 1) || y + 2 >= MAX - 1) {
                    temp.score += MAXD;
                }
                else if (((map[x][y - 3] == inverse * -1 && y - 3 > 0) || y - 3 <= 0) ||
                    (map[x][y + 2] == inverse * -1 && y + 2 < MAX - 1) || y + 2 >= MAX - 1) {
                    temp.score += MAXC;
                }
                else {
                    temp.score += MAXB;
                }
            }
            else if (((map[x][y - 2] == inverse * -1 && y - 2 > 0) || y - 2 <= 0) &&
                      ((map[x][y + 2] == inverse * -1 && y + 2 < MAX - 1) || y + 2 >= MAX - 1)) {
                temp.score += MAXE;
            }
            else if (((map[x][y - 2] == inverse * -1 && y - 2 > 0) || y - 2 <= 0) ||
                ((map[x][y + 2] == inverse * -1 && y + 2 < MAX - 1) || y + 2 >= MAX - 1)) {
                temp.score += MAXD;
            }
            else {
                temp.score += MAXC;
            }
        }//
        else if (((map[x][y - 1] == inverse * -1 && y - 1 > 0) || y - 1 <= 0)
            && ((map[x][y + 2] == inverse * -1 && y + 2 < MAX - 1) || y + 2 >= MAX - 1)) {
            temp.score += MAXF;
        }
        else if (((map[x][y - 1] == inverse * -1 && y - 1 > 0) || y - 1 <= 0)
            || ((map[x][y + 2] == inverse * -1 && y + 2 < MAX - 1) || y + 2 >= MAX - 1)) {
            temp.score += MAXE;
        }
        else {
            temp.score += MAXD;
        }
    }
    else {
        if (map[x][y - 1] == inverse && y - 1 > 0) {
            if (map[x][y - 2] == inverse && y - 2 > 0) {
                if (map[x][y - 3] == inverse && y - 3 > 0) {
                    if (map[x][y - 4] == inverse && y - 4 > 0) {
                        temp.score += MAXA;
                    }
                    else if (((map[x][y - 4] == inverse * -1 && y - 4 > 0) || y - 4 <= 0)
                        && ((map[x][y + 1] == inverse * -1 && y + 1 < MAX - 1) || y + 1 >= MAX - 1)) {
                        temp.score += MAXD;
                    }
                    else if (((map[x][y - 4] == inverse * -1 && y - 4 > 0) || y - 4 <= 0) 
                        || ((map[x][y + 1] == inverse * -1 && y + 1 < MAX - 1) || y + 1 >= MAX - 1)) {
                        temp.score += MAXC;
                    }
                    else {
                        temp.score += MAXB;
                    }
                }
                else if (((map[x][y - 3] == inverse * -1 && y - 3 > 0) || y - 3 <= 0)
                    && ((map[x][y + 1] == inverse * -1 && y + 1 < MAX - 1) || y + 1 >= MAX - 1)) {
                    temp.score += MAXE;
                }
                else if (((map[x][y - 3] == inverse * -1 && y - 3 > 0) || y - 3 <= 0) 
                    || ((map[x][y + 1] == inverse * -1 && y + 1 < MAX - 1) || y + 1 >= MAX - 1)) {
                    temp.score += MAXD;
                }
                else {
                    temp.score += MAXC;
                }
            }
            else if (((map[x][y - 2] == inverse * -1 && y - 2 > 0) || y - 2 <= 0)
                && ((map[x][y + 1] == inverse * -1 && y + 1 < MAX - 1) || y + 1 >= MAX - 1)) {
                temp.score += MAXF;
            }
            else if (((map[x][y - 2] == inverse * -1 && y - 2 > 0) || y - 2 <= 0)
                || ((map[x][y + 1] == inverse * -1 && y + 1 < MAX - 1) || y + 1 >= MAX - 1)) {
                temp.score += MAXE;
            }
            else {
                temp.score += MAXD;
            }
        }
        else if (((map[x][y - 1] == inverse * -1 && y - 1 > 0) || y - 1 <= 0)
            || ((map[x][y + 1] == inverse * -1 && y + 1 < MAX - 1) || y + 1 >= MAX - 1)) {
            temp.score += MAXG;
        }
        else {
            temp.score += MAXF;
        }
    }
    if (map[x + 1][y] == inverse && x + 1 < MAX - 1) {
        if (map[x + 2][y] == inverse && x + 2 < MAX - 1) {
            if (map[x + 3][y] == inverse && x + 3 < MAX - 1) {
                if (map[x + 4][y] == inverse && x + 4 < MAX - 1) {
                    temp.score += MAXA;
                }
                else if (map[x - 1][y] == inverse && x - 1 > 0) {
                    temp.score += MAXA;
                }
                else if (((map[x + 4][y] == inverse * -1 && x + 4 < MAX - 1) || x + 4 >= MAX - 1)
                     && ((map[x - 1][y] == inverse * -1 && x - 1 > 0) || x - 1 <= 0)) {
                    temp.score += MAXD;
                }
                else if (((map[x + 4][y] == inverse * -1 && x + 4 < MAX - 1) || x + 4 >= MAX - 1)
                    || ((map[x - 1][y] == inverse * -1 && x - 1 > 0) || x - 1 <= 0)) {
                    temp.score += MAXC;
                }
                else {
                    temp.score += MAXE;
                }
            }
            else if (map[x - 1][y] == inverse && x - 1 > 0) {
                if (map[x - 2][y] == inverse && x - 2 > 0) {
                    temp.score += MAXA;
                }
                else if (((map[x - 2][y] == inverse * -1 && x - 2 > 0) || x - 2 <= 0)
                        && ((map[x + 3][y] == inverse * -1 && x + 3 < MAX - 1) || x + 3 >= MAX - 1)) {
                    temp.score += MAXD;
                }
                else if (((map[x - 2][y] == inverse * -1 && x - 2 > 0) || x - 2 <= 0)
                      || ((map[x + 3][y] == inverse * -1 && x + 3 < MAX - 1) || x + 3 >= MAX - 1)) {
                    temp.score += MAXC;
                }
                else {
                    temp.score += MAXB;
                }
            }//
            else if (((map[x - 1][y] == inverse * -1 && x - 1 > 0) || x - 1 <= 0)
                && ((map[x + 3][y] == inverse * -1 && x + 3 < MAX - 1) || x + 3 >= MAX - 1)) {
                temp.score += MAXE;
            }
            else if (((map[x - 1][y] == inverse * -1 && x - 1 > 0) || x - 1 <= 0)
                || ((map[x + 3][y] == inverse * -1 && x + 3 < MAX - 1) || x + 3 >= MAX - 1)) {
                temp.score += MAXD;
            }
            else {
                temp.score += MAXC;
            }
        }
        else if (map[x - 1][y] == inverse && x - 1 > 0) {
            if (map[x - 2][y] == inverse && x - 2 > 0) {
                if (map[x - 3][y] == inverse && x - 3 > 0) {
                    temp.score += MAXA;
                }
                else if (((map[x - 3][y] == inverse * -1 && x - 3 > 0) || x - 3 <= 0) &&
                    (map[x + 2][y] == inverse * -1 && x + 2 < MAX - 1) || x + 2 >= MAX - 1) {
                    temp.score += MAXD;
                }
                else if (((map[x - 3][y] == inverse * -1 && x - 3 > 0) || x - 3 <= 0) ||
                    (map[x + 2][y] == inverse * -1 && x + 2 < MAX - 1) || x + 2 >= MAX - 1) {
                    temp.score += MAXC;
                }
                else {
                    temp.score += MAXB;
                }
            }
            else if (((map[x - 2][y] == inverse * -1 && x - 2 > 0) || x - 2 <= 0) &&
                ((map[x + 2][y] == inverse * -1 && x + 2 < MAX - 1) || x + 2 >= MAX - 1)){
                 temp.score += MAXE;
            }
            else if (((map[x - 2][y] == inverse * -1 && x - 2 > 0) || x - 2 <= 0) ||
                ((map[x + 2][y] == inverse * -1 && x + 2 < MAX - 1) || x + 2 >= MAX - 1)) {
                temp.score += MAXD;
            }
            else {
                temp.score += MAXC;
            }
        }
        else if (((map[x - 1][y] == inverse * -1 && x - 1 > 0) || x - 1 <= 0)
            && ((map[x + 2][y] == inverse * -1 && x + 2 < MAX - 1) || x + 2 >= MAX - 1)) {
            temp.score += MAXF;
        }
        else if (((map[x - 1][y] == inverse * -1 && x - 1 > 0) || x - 1 <= 0)
            || ((map[x + 2][y] == inverse * -1 && x + 2 < MAX - 1) || x + 2 >= MAX - 1)) {
            temp.score += MAXE;
        }
        else {
            temp.score += MAXD;
        }
    }
    else {
        if (map[x - 1][y] == inverse && x - 1 > 0) {
            if (map[x - 2][y] == inverse && x - 2 > 0) {
                if (map[x - 3][y] == inverse && x - 3 > 0) {
                    if (map[x - 4][y] == inverse && x - 4 > 0) {
                        temp.score += MAXA;
                    }
                    else if (((map[x - 4][y] == inverse * -1 && x - 4 > 0) || x - 4 <= 0)
                        && ((map[x + 1][y] == inverse * -1 && x + 1 < MAX - 1) || x + 1 >= MAX - 1)) {
                        temp.score += MAXD;
                    }
                    else if (((map[x - 4][y] == inverse * -1 && x - 4 > 0) || x - 4 <= 0)
                        || ((map[x + 1][y] == inverse * -1 && x + 1 < MAX - 1) || x + 1 >= MAX - 1)) {
                        temp.score += MAXC;
                    }
                    else {
                        temp.score += MAXB;
                    }
                }
                else if (((map[x - 3][y] == inverse * -1 && x - 3 > 0) || x - 3 <= 0)
                    && ((map[x + 1][y] == inverse * -1 && x + 1 < MAX - 1) || x + 1 >= MAX - 1)) {
                    temp.score += MAXE;
                }
                else if (((map[x - 3][y] == inverse * -1 && x - 3 > 0) || x - 3 <= 0)
                    || ((map[x + 1][y] == inverse * -1 && x + 1 < MAX - 1) || x + 1 >= MAX - 1)) {
                    temp.score += MAXD;
                }
                else {
                    temp.score += MAXC;
                }
            }
            else if (((map[x - 2][y] == inverse * -1 && x - 2 > 0) || x - 2 <= 0)
                && ((map[x + 1][y] == inverse * -1 && x + 1 < MAX - 1) || x + 1 >= MAX - 1)) {
                temp.score += MAXF;
            }
            else if (((map[x - 2][y] == inverse * -1 && x - 2 > 0) || x - 2 <= 0)
                || ((map[x + 1][y] == inverse * -1 && x + 1 < MAX - 1) || x + 1 >= MAX - 1)) {
                temp.score += MAXE;
            }
            else {
                temp.score += MAXD;
            }
        }
        else if (((map[x - 1][y] == inverse * -1 && x - 1 > 0) || x - 1 <= 0)
            || ((map[x + 1][y] == inverse * -1 && x + 1 < MAX - 1) || x + 1 >= MAX - 1)) {
            temp.score += MAXG;
        }
        else {
            temp.score += MAXF;
        }
    }
    if (map[x + 1][y + 1] == inverse && y + 1 < MAX - 1 && x + 1 < MAX - 1) {
        if (map[x + 2][y + 2] == inverse && y + 2 < MAX - 1 && x + 2 < MAX - 1) {
            if (map[x + 3][y + 3] == inverse && y + 3 < MAX - 1 && x + 3 < MAX - 1) {
                if (map[x + 4][y + 4] == inverse && y + 4 < MAX - 1 && x + 4 < MAX - 1) {
                    temp.score += MAXA;
                }
                else if (map[x - 1][y - 1] == inverse && y - 1 > 0 && x - 1 > 0) {
                    temp.score += MAXA;
                }
                else if (((map[x + 4][y + 4] == inverse * -1 && y + 4 < MAX - 1 && x + 4 < MAX - 1)
                    || y + 4 >= MAX - 1 || x + 4 >= MAX - 1)
                    && ((map[x - 1][y - 1] == inverse * -1 && y - 1 > 0 && x - 1 > 0)
                        || y - 1 <= 0 || x - 1 <= 0)) {
                    temp.score += MAXD;
                }
                else if (((map[x + 4][y + 4] == inverse * -1 && y + 4 < MAX - 1 && x + 4 < MAX - 1)
                    || y + 4 >= MAX - 1 || x + 4 >= MAX - 1)
                    || ((map[x - 1][y - 1] == inverse * -1 && y - 1 > 0 && x - 1 > 0)
                        || y - 1 <= 0 || x - 1 <= 0)) {
                    temp.score += MAXC;
                }
                else {
                    temp.score += MAXB;
                }
            }
            else if (map[x - 1][y - 1] == inverse && y - 1 > 0 && x - 1 > 0) {
                if (map[x - 2][y - 2] == inverse && y - 2 > 0 && x - 2 > 0) {
                    temp.score += MAXA;
                }
                else if (((map[x - 2][y - 2] == inverse * -1 && y - 2 > 0 && x - 2 > 0)
                    || y - 2 <= 0 || x - 2 <= 0)
                    && ((map[x + 3][y + 3] == inverse * -1 && y + 3 < MAX - 1 && x + 3 < MAX - 1)
                        || y + 3 >= MAX - 1 || x + 3 >= MAX - 1)) {
                    temp.score += MAXD;
                }
                else if ((map[x + 3][y + 3] == inverse * -1 && y + 3 < MAX - 1 && x + 3 < MAX - 1)
                    || y + 3 >= MAX - 1 || x + 3 >= MAX - 1) {
                    temp.score += MAXC;
                }
                else {
                    temp.score += MAXB;
                }
            }
            else if (((map[x - 1][y - 1] == inverse * -1 && y - 1 > 0 && x - 1 > 0)
                || y - 1 <= 0 || x - 1 <= 0)
                && ((map[x + 3][y + 3] == inverse * -1 && y + 3 < MAX - 1 && x + 3 < MAX - 1)
                    || y + 3 >= MAX - 1 || x + 3 >= MAX - 1)) {
                temp.score += MAXE;
            }
            else if (((map[x - 1][y - 1] == inverse * -1 && y - 1 > 0 && x - 1 > 0)
                || y - 1 <= 0 || x - 1 <= 0)
                || ((map[x + 3][y + 3] == inverse * -1 && y + 3 < MAX - 1 && x + 3 < MAX - 1)
                    || y + 3 >= MAX - 1 || x + 3 >= MAX - 1)) {
                temp.score += MAXD;
            }
            else {
                temp.score += MAXC;
            }
        }
        else if (map[x - 1][y - 1] == inverse && y - 1 > 0 && x - 1 > 0) {
            if (map[x - 2][y - 2] == inverse && y - 2 > 0 && x - 2 > 0) {
                if (map[x - 3][y - 3] == inverse && y - 3 > 0 && x - 3 > 0) {
                    temp.score += MAXA;
                }
                else if (((map[x - 3][y - 3] == inverse * -1 && x - 3 > 0 && y - 3 > 0) || x - 3 <= 0 || y - 3 <= 0) &&
                    (map[x + 2][y + 2] == inverse * -1 && x + 2 < MAX - 1 && y + 2 < MAX - 1)
                    || x + 2 >= MAX - 1 || y + 2 >= MAX - 1) {
                    temp.score += MAXD;
                }
                else if (((map[x - 3][y - 3] == inverse * -1 && x - 3 > 0 && y - 3 > 0) || x - 3 <= 0 || y - 3 <= 0) ||
                    (map[x + 2][y + 2] == inverse * -1 && x + 2 < MAX - 1 && y + 2 < MAX - 1)
                    || x + 2 >= MAX - 1 || y + 2 >= MAX - 1) {
                    temp.score += MAXC;
                }
                else {
                    temp.score += MAXB;
                }
            }
            else if (((map[x - 2][y - 2] == inverse * -1 && y - 2 > 0 && x - 2 > 0)
                || y - 2 <= 0 || x - 2 <= 0)
                && ((map[x + 2][y + 2] == inverse * -1 && y + 2 < MAX - 1 && x + 2 < MAX - 1)
                    || y + 2 >= MAX - 1 || x + 2 >= MAX - 1)) {
                temp.score += MAXE;
            }
            else if (((map[x - 2][y - 2] == inverse * -1 && y - 2 > 0 && x - 2 > 0)
                || y - 2 <= 0 || x - 2 <= 0)
                || ((map[x + 2][y + 2] == inverse * -1 && y + 2 < MAX - 1 && x + 2 < MAX - 1)
                    || y + 2 >= MAX - 1 || x + 2 >= MAX - 1)) {
                temp.score += MAXD;
            }
            else {
                temp.score += MAXC;
            }
        }//
        else if (((map[x - 1][y - 1] == inverse * -1 && y - 1 > 0 && x - 1 > 0)
            || y - 1 <= 0 || x - 1 <= 0)
            && ((map[x + 2][y + 2] == inverse * -1 && y + 2 < MAX - 1 && x + 2 < MAX - 1)
                || y + 2 >= MAX - 1 || x + 2 >= MAX - 1)) {
            temp.score += MAXF;
        }
        else if (((map[x - 1][y - 1] == inverse * -1 && y - 1 > 0 && x - 1 > 0)
            || y - 1 <= 0 || x - 1 <= 0)
            || ((map[x + 2][y + 2] == inverse * -1 && y + 2 < MAX - 1 && x + 2 < MAX - 1)
                || y + 2 >= MAX - 1 || x + 2 >= MAX - 1)) {
            temp.score += MAXE;
        }
        else {
            temp.score += MAXD;
        }
    }
    else {
        if (map[x - 1][y - 1] == inverse && y - 1 > 0 && x - 1 > 0) {
            if (map[x - 2][y - 2] == inverse && y - 2 > 0 && x - 2 > 0) {
                if (map[x - 3][y - 3] == inverse && y - 3 > 0 && x - 3 > 0) {
                    if (map[x - 4][y - 4] == inverse && y - 4 > 0 && x - 4 > 0) {
                        temp.score += MAXA;
                    }
                    else if (((map[x - 4][y - 4] == inverse * -1 && y - 4 > 0 && x - 4 > 0)
                        || y - 4 <= 0 || x - 4 <= 0)
                        && ((map[x + 1][y + 1] == inverse * -1 && y + 1 < MAX - 1 && x + 1 < MAX - 1)
                            || y + 1 >= MAX - 1 || x + 1 >= MAX - 1)) {
                        temp.score += MAXD;
                    }
                    else if (((map[x - 4][y - 4] == inverse * -1 && y - 4 > 0 && x - 4 > 0)
                        || y - 4 <= 0 || x - 4 <= 0)
                        || ((map[x + 1][y + 1] == inverse * -1 && y + 1 < MAX - 1 && x + 1 < MAX - 1)
                            || y + 1 >= MAX - 1 || x + 1 >= MAX - 1)) {
                        temp.score += MAXC;
                    }
                    else {
                        temp.score += MAXB;
                    }
                }
                else if (((map[x - 3][y - 3] == inverse * -1 && y - 3 > 0 && x - 3 > 0)
                    || y - 3 <= 0 || x - 3 <= 0)
                    && ((map[x + 1][y + 1] == inverse * -1 && y + 1 < MAX - 1 && x + 1 < MAX - 1)
                        || y + 1 >= MAX - 1 || x + 1 >= MAX - 1)) {
                    temp.score += MAXE;
                }
                else if (((map[x - 3][y - 3] == inverse * -1 && y - 3 > 0 && x - 3 > 0)
                    || y - 3 <= 0 || x - 3 <= 0)
                    || ((map[x + 1][y + 1] == inverse * -1 && y + 1 < MAX - 1 && x + 1 < MAX - 1)
                        || y + 1 >= MAX - 1 || x + 1 >= MAX - 1)) {
                    temp.score += MAXD;
                }
                else {
                    temp.score += MAXC;
                }
            }
            else if (((map[x - 2][y - 2] == inverse * -1 && y - 2 > 0 && x - 2 > 0)
                || y - 2 <= 0 || x - 2 <= 0)
                && ((map[x + 1][y + 1] == inverse * -1 && y + 1 < MAX - 1 && x + 1 < MAX - 1)
                    || y + 1 >= MAX - 1 || x + 1 >= MAX - 1)) {
                temp.score += MAXF;
            }
            else if (((map[x - 2][y - 2] == inverse * -1 && y - 2 > 0 && x - 2 > 0)
                || y - 2 <= 0 || x - 2 <= 0)
                && ((map[x + 1][y + 1] == inverse * -1 && y + 1 < MAX - 1 && x + 1 < MAX - 1)
                    || y + 1 >= MAX - 1 || x + 1 >= MAX - 1)) {
                temp.score += MAXE;
            }
            else {
                temp.score += MAXD;
            }
        }
        else if (((map[x - 1][y - 1] == inverse * -1 && y - 1 > 0 && x - 1 > 0)
            || y - 1 <= 0 || x - 1 <= 0)
            || ((map[x + 1][y + 1] == inverse * -1 && y + 1 < MAX - 1 && x + 1 < MAX - 1)
                || y + 1 >= MAX - 1 || x + 1 >= MAX - 1)) {
            temp.score += MAXG;
        }
        else {
            temp.score += MAXF;
        }
    }
    if (map[x + 1][y - 1] == inverse && y - 1 > 0 && x + 1 < MAX - 1) {
        if (map[x + 2][y - 2] == inverse && y - 2 > 0 && x + 2 < MAX - 1) {
            if (map[x + 3][y - 3] == inverse && y - 3 > 0 && x + 3 < MAX - 1) {
                if (map[x + 4][y - 4] == inverse && y - 4 > 0 && x + 4 < MAX - 1) {
                    temp.score += MAXA;
                }
                else if (map[x - 1][y + 1] == inverse && y + 1 < MAX - 1 && x - 1 > 0) {
                    temp.score += MAXA;
                }
                else if (((map[x + 4][y - 4] == inverse * -1 && y - 4 > 0 && x + 4 < MAX - 1)
                    || y - 4 <= 0 || x + 4 >= MAX - 1)
                    && ((map[x - 1][y + 1] == inverse * -1 && y + 1 < MAX - 1 && x - 1 > 0)
                        || y + 1 >= MAX - 1 || x - 1 <= 0)) {
                        temp.score += MAXD;
                }
                else if (((map[x + 4][y - 4] == inverse * -1 && y - 4 > 0 && x + 4 < MAX - 1)
                    || y - 4 <= 0 || x + 4 >= MAX - 1)
                    || ((map[x - 1][y + 1] == inverse * -1 && y + 1 < MAX - 1 && x - 1 > 0)
                        || y + 1 >= MAX - 1 || x - 1 <= 0)) {
                    temp.score += MAXC;
                }
                else {
                    temp.score += MAXB;
                }
            }
            else if (map[x - 1][y + 1] == inverse && y + 1 < MAX - 1 && x - 1 > 0) {
                if (map[x - 2][y + 2] == inverse && y + 2 < MAX - 1 && x - 2 > 0) {
                    temp.score += MAXA;
                }
                else if (((map[x - 2][y + 2] == inverse * -1 && y + 2 < MAX - 1 && x - 2 > 0)
                    || y + 2 >= MAX - 1 || x - 2 <= 0)
                    && ((map[x + 3][y - 3] == inverse * -1 && x + 3 < MAX - 1 && y - 3 > 0)
                        || x + 3 >= MAX - 1 || y - 3 <= 0)) {
                        temp.score += MAXD;
                }
                else if (((map[x - 2][y + 2] == inverse * -1 && y + 2 < MAX - 1 && x - 2 > 0)
                    || y + 2 >= MAX - 1 || x - 2 <= 0)
                    || ((map[x + 3][y - 3] == inverse * -1 && x + 3 < MAX - 1 && y - 3 > 0)
                        || x + 3 >= MAX - 1 || y - 3 <= 0)) {
                    temp.score += MAXC;
                }
                else {
                    temp.score += MAXB;
                }
            }
            else if (((map[x - 1][y + 1] == inverse * -1 && x - 1 > 0 && y + 1 < MAX - 1)
                || y + 1 >= MAX - 1 || x - 1 <= 0)
                && ((map[x + 3][y - 3] == inverse * -1 && y - 3 > 0 && x + 3 < MAX - 1)
                    || y - 3 <= 0 || x + 3 >= MAX - 1)) {
                temp.score += MAXE;
            }
            else if (((map[x - 1][y + 1] == inverse * -1 && y + 1 < MAX - 1 && x - 1 > 0)
                || y - 1 >= MAX - 1 || x - 1 <= 0)
                || ((map[x + 3][y - 3] == inverse * -1 && y - 3 > 0 && x + 3 < MAX - 1)
                    || y - 3 <= 0 || x + 3 >= MAX - 1)) {
                temp.score += MAXD;
            }
            else {
                temp.score += MAXC;//
            }
        }
        else if (map[x - 1][y + 1] == inverse && y + 1 < MAX - 1 && x - 1 > 0) {
            if (map[x - 2][y + 2] == inverse && y + 2 < MAX - 1 && x - 2 > 0) {
                if (map[x - 3][y + 3] == inverse && x - 3 > 0 && y + 3 < MAX - 1) {
                    temp.score += MAXA;
                }
                else if (((map[x - 3][y + 3] == inverse * -1 && x - 3 > 0 && y + 3 < MAX - 1) || x - 3 <= 0 || y + 3 >= MAX - 1) &&
                    (map[x + 2][y - 2] == inverse * -1 && x + 2 < MAX - 1 && y - 2 > 0)
                    || x + 2 >= MAX - 1 || y - 2 <= 0) {
                    temp.score += MAXD;
                }
                else if (((map[x - 3][y + 3] == inverse * -1 && x - 3 > 0 && y + 3 < MAX - 1) || x - 3 <= 0 || y + 3 >= MAX - 1) ||
                    (map[x + 2][y - 2] == inverse * -1 && x + 2 < MAX - 1 && y - 2 > 0)
                    || x + 2 >= MAX - 1 || y - 2 <= 0) {
                    temp.score += MAXC;
                }
                else {
                    temp.score += MAXB;
                }
            }
            else if (((map[x - 2][y + 2] == inverse * -1 && y + 2 < MAX - 1 && x - 2 > 0)
                || y + 2 >= MAX - 1 || x - 2 <= 0)
                && ((map[x + 2][y - 2] == inverse * -1 && y - 2 > 0 && x + 2 < MAX - 1)
                    || x + 2 >= MAX - 1 || y - 2 <= 0)) {
                    temp.score += MAXE;
            }
            else if (((map[x - 2][y + 2] == inverse * -1 && y + 2 < MAX - 1 && x - 2 > 0)
                || y + 2 >= MAX - 1 || x - 2 <= 0)
                && ((map[x + 2][y - 2] == inverse * -1 && y - 2 > 0 && x + 2 < MAX - 1)
                    || x + 2 >= MAX - 1 || y - 2 <= 0)) {
                temp.score += MAXD;
            }
            else {
                temp.score += MAXC;
            }
        }//
        else if (((map[x - 1][y + 1] == inverse * -1 && x - 1 > 0 && y + 1 < MAX - 1)
            || x - 1 <= 0 || y + 1 >= MAX - 1)
            && ((map[x + 2][y - 2] == inverse * -1 && y - 2 > 0 && x + 2 < MAX - 1)
                || y - 2 <= 0 || x + 2 >= MAX - 1)) {
            temp.score += MAXF;
        }
        else if (((map[x - 1][y + 1] == inverse * -1 && y + 1 < MAX - 1 && x - 1 > 0)
            || y + 1 >= MAX - 1 || x - 1 <= 0)
            || ((map[x + 2][y - 2] == inverse * -1 && y - 2 > 0 && x + 2 < MAX - 1)
                || y - 2 <= 0 || x + 2 >= MAX - 1)) {
            temp.score += MAXE;
        }
        else {
            temp.score += MAXD;
        }
    }
    else {
        if (map[x - 1][y + 1] == inverse && y + 1 < MAX - 1 && x - 1 > 0) {
            if (map[x - 2][y + 2] == inverse && y + 2 < MAX - 1 && x - 2 > 0) {
                if (map[x - 3][y + 3] == inverse && y + 3 < MAX - 1 && x - 3 > 0) {
                    if (map[x - 4][y + 4] == inverse && y + 4 < MAX - 1 && x - 4 > 0) {
                        temp.score += MAXA;
                    }
                    else if (((map[x - 4][y + 4] == inverse * -1 && y + 4 < MAX - 1 && x - 4 > 0)
                        || y + 4 >= MAX - 1 || x - 4 <= 0)
                        && ((map[x + 1][y - 1] == inverse * -1 && y - 1 > 0 && x + 1 < MAX - 1)
                            || y - 1 <= 0 || x + 1 >= MAX - 1)) {
                        temp.score += MAXD;
                    }
                    else if (((map[x - 4][y + 4] == inverse * -1 && y + 4 < MAX - 1 && x - 4 > 0)
                        || y + 4 >= MAX - 1 || x - 4 <= 0)
                        || ((map[x + 1][y - 1] == inverse * -1 && y - 1 > 0 && x + 1 < MAX - 1)
                            || y - 1 <= 0 || x + 1 >= MAX - 1)) {
                        temp.score += MAXC;
                    }
                    else {
                        temp.score += MAXB;
                    }
                }
                else if (((map[x - 3][y + 3] == inverse * -1 && y + 3 < MAX - 1 && x - 3 > 0)
                    || y + 3 >= MAX - 1 || x - 3 <= 0)
                    && ((map[x + 1][y - 1] == inverse * -1 && y - 1 > 0 && x + 1 < MAX - 1)
                        || y - 1 <= 0 || x + 1 >= MAX - 1)) {
                    temp.score += MAXE;
                }
                else if (((map[x - 3][y + 3] == inverse * -1 && y + 3 < MAX - 1 && x - 3 > 0)
                    || y + 3 >= MAX - 1 || x - 3 <= 0)
                    && ((map[x + 1][y - 1] == inverse * -1 && y - 1 > 0 && x + 1 < MAX - 1)
                        || y - 1 <= 0 || x + 1 >= MAX - 1)) {
                    temp.score += MAXD;
                }
                else {
                    temp.score += MAXC;
                }
            }
            else if (((map[x - 2][y + 2] == inverse * -1 && y + 2 < MAX - 1 && x - 2 > 0)
                || y + 2 >= MAX - 1 || x - 2 <= 0)
                && ((map[x + 1][y - 1] == inverse * -1 && y - 1 > 0 && x + 1 < MAX - 1)
                    || y - 1 <= 0 || x + 1 >= MAX - 1)) {
                temp.score += MAXF;
            }
            else if (((map[x - 2][y + 2] == inverse * -1 && y + 2 < MAX - 1 && x - 2 > 0)
                || y + 2 >= MAX - 1 || x - 2 <= 0)
                && ((map[x + 1][y - 1] == inverse * -1 && y - 1 > 0 && x + 1 < MAX - 1)
                    || y - 1 <= 0 || x + 1 >= MAX - 1)) {
                temp.score += MAXE;
            }
            else {
                temp.score += MAXD;
            }
        }
        else if (((map[x - 1][y + 1] == inverse * -1 && y + 1 < MAX - 1 && x - 1 > 0)
            || y + 1 >= MAX - 1 || x - 1 <= 0)
            || ((map[x + 1][y - 1] == inverse * -1 && y - 1 > 0 && x + 1 < MAX - 1)
                || y - 1 <= 0 || x + 1 >= MAX - 1)) {
            temp.score += MAXG;
        }
        else {
            temp.score += MAXF;
        }
    }
    if (g < 1) {
        point temp2 = score_judge(x, y, inverse * -1, g + 1);
        if (abs(temp2.score) >= abs(temp.score)) {
            temp.score += testai * abs(temp2.score);
        }
    }
    temp.score *= inverse;
    return temp;
}

void game_start() {
    bool start = 0;
    point p = { 8,8,0 };
    point ai = p;
    display_map();
    srand((unsigned int)time(nullptr));
    int judge = rand() % 2;
    
    while (!end_game) {
        map[p.x][p.y] = -2;
        if (!start) {
            map[p.x][p.y] = 2;
            start = 1;
        }
        player_move(p);
        paint(p.x, p.y);
        if (exit_chess) {
            end_game = 4;
            break;
        }
        end_game = win_judge();
        if (end_game) {
            break;
        }
        ai = ai_main_algorithm(p, 1, WHITE);
        map[ai.x][ai.y] = BLACK;
        paint(ai.x, ai.y);
        end_game = win_judge();
    }/*
    while (!end_game) {
        if (!start) {
            start = 1;
        }
        else {
            p = ai_main_algorithm(p, 1, WHITE);
        }
        map[p.x][p.y] = BLACK;
        paint(p.x,p.y);
        end_game = win_judge();
        if (end_game) {
            break;
        }
        map[p.x][p.y] = 3;
        player_move(p);
        if (exit_chess) {
            end_game = 4;
            break;
        }
        paint(p.x,p.y);
        end_game = win_judge();
    }*/
    Sleep(1000);
    switch (end_game) {
    case 1://ai
        putimage(size * 4, size * 4, &img[6]);
        break;
    case -1://pl
        putimage(size * 4, size * 4, &img[5]);
        break;
    case 3:
        putimage(size * 4, size * 4, &img[4]);
        break;
    default:
        putimage(size * 4, size * 4, &img[4]);
        break;
    }
    Sleep(1000);
}

point ai_main_algorithm(const point p, int generation, int inverse) {
    if (generation == 4) {
        return score_judge(p.x, p.y, inverse, 0);
    }
    long long score = score_judge(p.x, p.y, inverse, 0).score;
    long long temp_max = -21474836480;
    point ans = { -1,-1,0ll };
    for (int i = 1; i < MAX - 1; i++) {
        for (int j = 1; j < MAX - 1; j++) {
            if (map[i][j] != 0) {
                continue;
            }
            map[i][j] = inverse * -1;
            point temp = { i,j,0ll };
            if (ans.x == -1) {
                ans = temp;
            }
            if (generation == 1 && win_judge() == BLACK) {
                map[i][j] = NO;
                return temp;
            }
            long long score_temp = score + ai_main_algorithm(temp, generation + 1, inverse * -1).score;
            if (score_temp > temp_max) {
                temp_max = score_temp;
                ans = temp; ans.score = temp_max;
            }
            map[i][j] = NO;
        }
    }
    return ans;
}