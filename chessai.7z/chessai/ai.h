#pragma once

#include"map.h"

extern int map[MAX][MAX];
extern int end_game;
extern IMAGE img[100];
extern bool exit_chess;

point score_judge(int x, int y, int inverse, int g);
point ai_main_algorithm(const point p, int generation, int inverse);
void game_start();

