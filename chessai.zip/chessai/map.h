#pragma once

#include<cstdio>
#include<windows.h>
#include<conio.h>
#include<cmath>
#include<graphics.h>
#include<ctime>
#include<cassert>
#define BLACK 1
#define WHITE -1
#define NO 0
#define size 50
#define MAXA 100000
#define MAXB 10000
#define MAXC 1000
#define MAXD 100
#define MAXE 10
#define MAXF 1
#define MAXG 0
#define testai 5
#define MAX 17

typedef struct point_ {
    int x, y;
    long long score;
}point;

bool judge_position(point& player);
void paint(int i, int j);
void display_map(); 
point player_move(point& player); 
int win_judge();

