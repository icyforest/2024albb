#include"map.h"

extern int map[MAX][MAX];
extern int end_game;
extern IMAGE img[100];
extern bool exit_chess;

bool judge_position(point& player) {
    int x = player.x, y = player.y;
    if (x >= 1 && y >= 1 && x < MAX - 1 && y < MAX - 1 && map[x][y] == 2) {
        return true;
    }
    return false;
}

point player_move(point& player) {
    bool judge = false;
    while (1) {
        ExMessage pl;
        getmessage(&pl, EM_KEY);
        getmessage(&pl, EM_KEY);
        point temp = player;
        switch (pl.vkcode) {
        case 'A':
        case VK_LEFT:
            temp.y--;
            break;
        case 'S':
        case VK_DOWN:
            temp.x++;
            break;
        case 'W':
        case VK_UP:
            temp.x--;
            break;
        case 'D':
        case VK_RIGHT:
            temp.y++;
            break;
        case 13:
            judge = true;
            break;
        case 27:
            exit_chess = true;
            return player;
            break;
        default:
            break;
        }
        if (judge) {
            if (!judge_position(temp)) {
                judge = false;
                continue;
            }
            else {
                map[temp.x][temp.y] = WHITE;
                player = temp;
                return temp;
            }
        }
        if (temp.x < 1 || temp.y < 1 || temp.x >= MAX - 1 || temp.y >= MAX - 1) {
            continue;
        }
        switch (map[player.x][player.y]) {
        case 2:
            map[player.x][player.y] = NO;
            break;
        case -2:
            map[player.x][player.y] = WHITE;
            break;
        case 3:
            map[player.x][player.y] = BLACK;
            break;
        default:
            break;
        }
        paint(player.x, player.y);
        switch (map[temp.x][temp.y]) {
        case 0:
            map[temp.x][temp.y] = 2;
            break;
        case WHITE:
            map[temp.x][temp.y] = -2;
            break;
        case BLACK:
            map[temp.x][temp.y] = 3;
            break;
        default:
            break;
        }
        player = temp;
        paint(player.x, player.y);
    }
    return player;
}

int win_judge() {
    int win = 0;
    bool full = true;
    for (int i = 1; i < MAX - 1; i++) {
        for (int j = 1; j < MAX - 1; j++) {
            if (map[i][j] == 0) {
                full = false;
                break;
            }
        }
    }
    for (int i = 1; i < MAX - 1; i++) {
        for (int j = 1; j < MAX - 5; j++) {
            if (map[i][j] == BLACK && map[i][j + 1] == BLACK
                && map[i][j + 2] == BLACK && map[i][j + 3] == BLACK
                && map[i][j + 4] == BLACK) {
                return BLACK;
            }
            if (map[i][j] == WHITE && map[i][j + 1] == WHITE
                && map[i][j + 2] == WHITE && map[i][j + 3] == WHITE
                && map[i][j + 4] == WHITE) {
                return WHITE;
            }
        }
    }
    for (int i = 1; i < MAX - 5; i++) {
        for (int j = 1; j < MAX - 1; j++) {
            if (map[i][j] == BLACK && map[i + 1][j] == BLACK
                && map[i + 2][j] == BLACK && map[i + 3][j] == BLACK
                && map[i + 4][j] == BLACK) {
                return BLACK;
            }
            if (map[i][j] == WHITE && map[i + 1][j] == WHITE
                && map[i + 2][j] == WHITE && map[i + 3][j] == WHITE
                && map[i + 4][j] == WHITE) {
                return WHITE;
            }
        }
    }
    for (int i = 1; i < MAX - 5; i++) {
        for (int j = 1; j < MAX - 5; j++) {
            if (map[i][j] == BLACK && map[i + 1][j + 1] == BLACK
                && map[i + 2][j + 2] == BLACK && map[i + 3][j + 3] == BLACK
                && map[i + 4][j + 4] == BLACK) {
                return BLACK;
            }
            if (map[i][j] == WHITE && map[i + 1][j + 1] == WHITE
                && map[i + 2][j + 2] == WHITE && map[i + 3][j + 3] == WHITE
                && map[i + 4][j + 4] == WHITE) {
                return WHITE;
            }
        }
    }
    for (int i = 1; i < MAX - 5; i++) {
        for (int j = MAX - 1; j > 4; j--) {
            if (map[i][j] == BLACK && map[i + 1][j - 1] == BLACK
                && map[i + 2][j - 2] == BLACK && map[i + 3][j - 3] == BLACK
                && map[i + 4][j - 4] == BLACK) {
                return BLACK;
            }
            if (map[i][j] == WHITE && map[i + 1][j - 1] == WHITE
                && map[i + 2][j - 2] == WHITE && map[i + 3][j - 3] == WHITE
                && map[i + 4][j - 4] == WHITE) {
                return WHITE;
            }
        }
    }
    if (full) {
        return 3;
    }
    return win;
}

void paint(int i, int j) {
    if (map[i][j] == 0) {
        putimage((j - 1) * size, (i - 1) * size, &img[3]);
    }
    else if (map[i][j] == 1) {
        putimage((j - 1) * size, (i - 1) * size, &img[2]);
    }
    else if (map[i][j] == -1) {
        putimage((j - 1) * size, (i - 1) * size, &img[0]);
    }
    else if (map[i][j] == 2) {
        putimage((j - 1) * size, (i - 1) * size, &img[1]);
    }//NO
    else if (map[i][j] == -2) {
        putimage((j - 1) * size, (i - 1) * size, &img[1]);
    }//WHITE
    else if (map[i][j] == 3) {
        putimage((j - 1) * size, (i - 1) * size, &img[1]);
    }//BLACK
}

void display_map() {
    for (int i = 1; i < MAX - 1; i++) {
        for (int j = 1; j < MAX - 1; j++) {
            paint(i, j);
        }
    }
}