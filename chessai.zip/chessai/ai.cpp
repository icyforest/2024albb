#include"ai.h"

extern int map[MAX][MAX];
extern int end_game;
extern IMAGE img[100];
extern bool exit_chess;

int main()
{
    initgraph((MAX - 2) * size, (MAX - 2) * size);
    loadimage(&img[0], L"./white.jpg", size, size);
    loadimage(&img[1], L"./whiting.jpg", size, size);
    loadimage(&img[2], L"./black.jpg", size, size);
    loadimage(&img[3], L"./no.jpg", size, size);
    loadimage(&img[4], L"./bye.jpg", size * 5, size * 5);
    loadimage(&img[5], L"./win.jpg", size * 5, size * 5);
    loadimage(&img[6], L"./lose.jpg", size * 5, size * 5);
    while (1) {
        if (exit_chess) {
            break;
        }
        for (int i = 0; i < MAX; i++) {
            for (int j = 0; j < MAX; j++) {
                map[i][j] = 0;
            }
        }
        end_game = 0;
        game_start();
    }
    return 0;
}
